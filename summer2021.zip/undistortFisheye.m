% close all
clc
clear
LargeW = 600;

I = imread("/Users/jin/Desktop/FLIR_rect/png/43.png");
% nnz(I)/nnz(ones(size(I)))

[h,w,d] = size(I);

for i =1:h
    for j = 1:w
        if(norm([j,i]-[w/2,h/2])>600)
            I(i,j,:) = [0,0,0];
        end
    end
end
% nnz(I)/nnz(ones(size(I)))
% figure,
% subplot(1,2,1)
% imshow(I)
% subplot(1,2,2),imshow(I)
%
%
% focal_length = 100:100:700;
% focal_length = 400:20:500;
% t265 286.28
% FLIR 386.55
focal_length = 400; 
% figure
for idx = 1:length(focal_length)
    LargerI = zeros(LargeW,LargeW,3);
    Iremap = zeros(size(I));
    
    for i = 1:h
        for j = 1:w
            [pt2dL,focal_length] = liftProjectiveMei([j,i]);
            
            x = (round(pt2dL(2)))+LargeW/2;
            y = (round(pt2dL(1)))+LargeW/2;
            if ( x<LargeW && y<LargeW && x>1 && y>1 )
                if (isreal(pt2dL))
                    LargerI(x,y,:) = I(i,j,:);
                    Iremap(i,j,:) = I(i,j,:);
%                 else
%                     IremapValid = Iremap;
%                     IremapValid(i,j,:) = [255,0,0];
                end
                
            end
            
        end
    end
    %
    Iremap = uint8(Iremap);
%     IremapValid = uint8(IremapValid);
    LargerI = uint8(LargerI);
    
    figure,
    tl = tiledlayout(1,2);
    nexttile(tl)
    imshow(LargerI)
    hold on
    plot(LargeW/2,LargeW/2,'r*')
    nexttile(tl)
    imshow(Iremap)
    title(tl,"focal length @ "+num2str(focal_length(idx))+" pixel",'FontSize',20,'FontWeight','bold');

%     figure,
%     imshow(LargerI)
end
%
% nnz(LargerI)/nnz(ones(LargeW,LargeW,3))
% nnz(Iremap)/nnz(I)

set(gcf,'color','w');
set(gca,'color','w');



imwrite(LargerI,"/Users/jin/Desktop/FisheyeExpension/expended/center.png")
imwrite(Iremap,"/Users/jin/Desktop/FisheyeExpension/expended/centerRaw.png")

%%
I_left = imread("/Users/jin/Desktop/FisheyeExpension/expended/left.png");
I_right = imread("/Users/jin/Desktop/FisheyeExpension/expended/right.png");
I_top = imread("/Users/jin/Desktop/FisheyeExpension/expended/top.png");
I_bottom = imread("/Users/jin/Desktop/FisheyeExpension/expended/bottom.png");
I_center = imread("/Users/jin/Desktop/FisheyeExpension/expended/center.png");

Icube = zeros(1800,1800,3);

Icube(1:600,1+600:600+600,:) = I_top;
Icube(1+1200:600+1200,1+600:600+600,:) = I_bottom;
Icube(1+600:600+600,1+600:600+600,:) = I_center;
Icube(1+600:600+600,1:600,:) = I_left;
Icube(1+600:600+600,1+1200:600+1200,:) = I_right;



Icube=uint8(Icube);imshow(Icube)
imwrite(Icube,"/Users/jin/Desktop/FisheyeExpension/expended/flatCube.png")
%%
% LargerIg = rgb2gray(LargerI);
% %
% figure,imshow(LargerIg)
% LargerIF = double(LargerIg);
% LargerIF(LargerIF(:,:)==0)=nan;
% r = 1:LargeW;
% for i = 1:LargeW
%     [F,TF] = fillmissing(LargerIF(i,:),'linear','SamplePoints',r);
%     LargerIF(i,:) = F;
% end
% 
% for i = 1:LargeW
%     [F,TF] = fillmissing(LargerIF(:,i),'linear','SamplePoints',r);
%     LargerIF(:,i) = F;
% end
% 
% LargerIF = uint8(LargerIF);
% figure,imshow(LargerIF)
% nnz(LargerIF)/nnz(ones(LargeW,LargeW))

%%
%%
figure,imshow(LargerI)
LargerIF = double(LargerI);
LargerIdpuble = double(LargerI);
LargerIdpuble(LargerIdpuble(:,:,:)==0)=nan;
LargerIF(LargerIF(:,:,:)==0)=nan;
LargeW = 2048;
r = 1:LargeW;
for i = 1:LargeW
%     [F,TF] = fillmissing(LargerIF(i,:,:),'spline','SamplePoints',r);
    [F,TF] = fillmissing(LargerIdpuble(i,:,:),'linear','SamplePoints',r);
%     F = fillmissing(LargerIdpuble(i,:,:),'movmedian',20);
    LargerIF(i,:,:) = F;
    
%     F = fillmissing(LargerIdpuble(:,i,:),'movmedian',20);
%     LargerIF(:,i,:) = F;
    
end

for i = 1:LargeW
    [F,TF] = fillmissing(LargerIF(:,i,:),'linear','SamplePoints',r);
    LargerIF(:,i,:) = F;
end

LargerIF = uint8(LargerIF);
figure,imshow(LargerIF)
nnz(LargerIF)/nnz(ones(LargeW,LargeW,3))