
ddd1 = importdata("/Users/jin/vins_result_no_loop2_cp.csv");

figure,plot3(ddd1(:,2),ddd1(:,3),ddd1(:,4),'b.','LineWidth',1)


ddd1 = importdata("/Users/jin/orb3_3/CameraTrajectory_cp.txt");
rot = [  -0.999971         0.00287617       0.00707827    
  -0.00286042      -0.999993         0.00223534    
   0.00708466       0.00221503       0.999973  ];
ddd1(:,2:4) = ddd1(:,2:4)*rot;
hold on ,plot3(ddd1(:,2),ddd1(:,3),ddd1(:,4),'r.','LineWidth',1),axis equal,grid minor
